<?php
 define("DB_HOST","localhost");
 define("DB_USER","DB���̵�");
 define("DB_PASSWORD","DB�н�����");
 define("DB_DATABASE","DB�̸�");

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');


if (isset($_POST['stu_id']) && isset($_POST['title'])) {

    // receiving the post params
    $stu_id = $_POST['stu_id'];
    $title = $_POST['title'];

    $sql = "UPDATE board SET see = see + 1 WHERE stu_id = '$stu_id' AND title = '$title'";
      mysqli_query($con, $sql);  
      mysqli_close($con);

}
?>


