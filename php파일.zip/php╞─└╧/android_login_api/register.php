<?php
 
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
 
// json response array
$response = array("error" => FALSE);
 
if (isset($_POST['name']) && isset($_POST['stu_id']) && isset($_POST['password']) && isset ($_POST['category'])) {
 
    // receiving the post params
    $name = $_POST['name'];
    $stu_id = $_POST['stu_id'];
    $password = $_POST['password'];
    $category = $_POST['category'];
    // check if user is already existed with the same email
    if ($db->isUserExisted($stu_id)) {
        // user already existed
        $response["error"] = TRUE;
        $response["error_msg"] = "�ش� ������ �̹� �����մϴ� : " . $stu_id;
        echo json_encode($response);
    } else {
        // create a new user
        $user = $db->storeUser($name, $stu_id, $password, $category);
        if ($user) {
            // user stored successfully
            $response["error"] = FALSE;
            $response["uid"] = $user["unique_id"];
            $response["user"]["name"] = $user["name"];
            $response["user"]["stu_id"] = $user["stu_id"];
	    $response["user"]["category"] = $user["category"];
	    $response["user"]["tickets"] = $user["tickets"];
            $response["user"]["created_at"] = $user["created_at"];
            $response["user"]["updated_at"] = $user["updated_at"];
            echo json_encode($response);
        } else {
            // user failed to store
            $response["error"] = TRUE;
            $response["error_msg"] = "Unknown error occurred in registration!";
            echo json_encode($response);
        }
    }
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "�Է°��� ����ֽ��ϴ�";
    echo json_encode($response);
}
?>

