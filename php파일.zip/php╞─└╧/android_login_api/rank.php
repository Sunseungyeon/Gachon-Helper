<?php
 define("DB_HOST","localhost");
 define("DB_USER","DB���̵�");
 define("DB_PASSWORD","DB�н�����");
 define("DB_DATABASE","DB�̸�");

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');

    

        $sql = "SELECT name,stu_id,tickets FROM users ORDER BY ABS(tickets) DESC limit 3";
        $search = mysqli_query($con, $sql);
	
	$result = array();

	while($row = mysqli_fetch_array($search)){
		array_push($result,array(
		"name" => $row['name'],
		"stu_id" => $row['stu_id'],
		"tickets" => $row['tickets']
	)
	);
	}
	echo json_encode(array("result"=>$result));
	    
    mysqli_close($con);

?>

