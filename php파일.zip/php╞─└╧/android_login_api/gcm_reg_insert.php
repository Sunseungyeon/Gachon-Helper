<?php
 define("DB_HOST","localhost");
 define("DB_USER","DB���̵�");
 define("DB_PASSWORD","DB�н�����");
 define("DB_DATABASE","DB�̸�");

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');


if (isset($_POST['stu_id']) && isset($_POST['reg_id'])){
	
	$stu_id = $_POST['stu_id'];
	$reg_id = $_POST['reg_id'];

	$sql = "UPDATE users SET reg_id = '$reg_id' WHERE stu_id = '$stu_id'";
	mysqli_query($con,$sql);

  }else{
	$response = array();
	$response["error"] = TRUE;
	$response["error_msg"] = "GCM Error"
	echo json_encode($response);
}
	mysqli_close($con);
?>
