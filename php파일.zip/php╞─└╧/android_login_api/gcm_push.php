<?php

	
	$reg_id = "�Է¹��� ��ū ���̵�";	
	$headers = array(
		'Content-Type:application/json',
		'Authorization:key=AIzaSyCFw7QoBQzklpfEe5rLT7eYACDrusLLU1Q'
		);

	$arr = array();
	$arr['data'] = array();
	$arr['data']['title'] = 'push test';
	$arr['data']['message'] = 'this is text message and push success!!';
	$arr['registration_ids'] = array();
	$arr['registration_ids'][0] = $reg_id;

	$ch = curl_init();

	curl_setopt($ch, CURLOPT_URL, 'https://android.googleapis.com/gcm/send');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($arr));
        $response = curl_exec($ch);
        curl_close($ch);

	$obj = json_decode($response);

?>
