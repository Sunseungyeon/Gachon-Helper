<?php
 define("DB_HOST","localhost");
 define("DB_USER","DB���̵�");
 define("DB_PASSWORD","DB�н�����");
 define("DB_DATABASE","DB�̸�");

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
 
	 if(isset($_POST['stu_id']) && isset($_POST['category'])){
		
		 $stu_id = $_POST['stu_id'];
	 	 $category = $_POST['category'];
	
		 $sql = "UPDATE users SET category = '$category' WHERE stu_id = '$stu_id'";
	 	 mysqli_query($con,$sql);

	}else{
		 $response = array();
		 $response["error"] = TRUE;
		 $response["error_msg"] = "���� ������ �� �� �����ϴ�.";
		 echo json_encode($response);	
	
	}
	mysqli_close($con);
?>	
