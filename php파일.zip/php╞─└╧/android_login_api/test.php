<?php
 define("DB_HOST","localhost");
 define("DB_USER","DB���̵�");
 define("DB_PASSWORD","DB�н�����");
 define("DB_DATABASE","DB�̸�");

 $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to connect');
 mysqli_query($mysqli,"set names utf8");


if(isset ($_POST['helpy_stu_id'])){

 $helpy_stu_id = $_POST['helpy_stu_id'];
 $sql = "SELECT reg_id FROM users WHERE stu_id = '$helpy_stu_id'";
 $result = mysqli_query($con,$sql);
 $row = mysqli_fetch_row($result);
 $helpy_token['token'] = $row[0];

$url    = 'https://android.googleapis.com/gcm/send';
 
//your api key
$apiKey = 'AIzaSyCFw7QoBQzklpfEe5rLT7eYACDrusLLU1Q';
 
//registration ids
$registrationIDs = array($row[0]);
 
//payload data
$message = iconv("EUC-KR", "UTF-8", "���� ����..!!(�ε�))");
$fields = array('registration_ids' => $registrationIDs,
                'data' => array("message" => $message),);

 
 
//http header
$headers = array('Authorization: key=' . $apiKey,
                 'Content-Type: application/json');
 
//curl connection
$ch = curl_init();
 
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
 
$result = curl_exec($ch);
 
curl_close($ch);
 
echo $result;
}
?>

