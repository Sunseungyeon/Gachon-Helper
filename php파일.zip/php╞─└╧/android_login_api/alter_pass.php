<?php
require_once 'include/DB_Functions.php';
$db = new DB_Functions();

// json response array
$response = array("error" => FALSE);

if (isset($_POST['stu_id']) && isset($_POST['password']) && isset($_POST['c_password'])) {

    // receiving the post params
    $stu_id = $_POST['stu_id'];
    $password = $_POST['password'];
    $c_password = $_POST['c_password'];

    // get the user by ID and password
    $user = $db->getUserByIdAndPassword($stu_id, $password);

    if ($user) {
        // use is found
 define("DB_HOST","localhost");
 define("DB_USER","DB���̵�");
 define("DB_PASSWORD","DB�н�����");
 define("DB_DATABASE","DB�̸�");


	$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');

    
        $sql1 = "SELECT salt FROM users WHERE stu_id = '$stu_id'";
        $result = mysqli_query($con,$sql1);
        $row = mysqli_fetch_row($result);
        $salt['salt'] = $row[0];
	
	$encrypted_password = $db->checkhashSSHA($row[0], $c_password);

        $sql = "UPDATE users SET encrypted_password = '$encrypted_password'  WHERE stu_id = '$stu_id'";
        mysqli_query($con,$sql);
        mysqli_close($con);

	$response["salt"] = $row[0];
	$response["encrypted_password"] = $encrypted_password;
        echo json_encode($response);
    } else {
        // user is not found with the credentials
        $response["error"] = TRUE;
        $response["error_msg"] = "ȸ�������� ��ġ���� �ʽ��ϴ�.";
        echo json_encode($response);
    }
}

?>
