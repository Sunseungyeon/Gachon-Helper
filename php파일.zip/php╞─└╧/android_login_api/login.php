<?php
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
 
// json response array
$response = array("error" => FALSE);

if (isset($_POST['stu_id']) && isset($_POST['password']) && isset($_POST['token'])) {
 
    // receiving the post params
    $stu_id = $_POST['stu_id'];
    $password = $_POST['password'];
    $reg_id = $_POST['token'];
    
    
    // get the user by ID and password
    $user = $db->getUserByIdAndPassword($stu_id, $password);
 
    if ($user) {
        // use is found
        $response["error"] = FALSE;
        $response["uid"] = $user["unique_id"];
        $response["user"]["name"] = $user["name"];
        $response["user"]["stu_id"] = $user["stu_id"];
	$response["user"]["category"] = $user["category"];
	$response["user"]["tickets"] = $user["tickets"];
        $response["user"]["created_at"] = $user["created_at"];
        $response["user"]["updated_at"] = $user["updated_at"];	

 define("DB_HOST","localhost");
 define("DB_USER","DB���̵�");
 define("DB_PASSWORD","DB�н�����");
 define("DB_DATABASE","DB�̸�");

 	$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
	$sql = "UPDATE users SET reg_id = '$reg_id' WHERE stu_id = '$stu_id'";
	mysqli_query($con,$sql);
	mysqli_close($con);
	
        echo json_encode($response);
    } else {
        // user is not found with the credentials
        $response["error"] = TRUE;
        $response["error_msg"] = "�α��� ������ ��ġ���� �ʽ��ϴ�. �ٽ� �õ��� �ּ���";
        echo json_encode($response);
    }
} else {
    // required post params is missing
    $response["error"] = TRUE;
    $response["error_msg"] = "ID�� ��й�ȣ�� �Է����ּ���";
    echo json_encode($response);
}
?>

